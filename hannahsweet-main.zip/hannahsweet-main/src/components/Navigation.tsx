import { NavLink } from "./NavLink";

const Navigation = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-border/50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold gradient-text">
            Hannah
          </div>
          <div className="flex gap-8">
            <NavLink
              to="/home"
              className="text-foreground/80 hover:text-foreground transition-colors font-medium"
              activeClassName="text-foreground gradient-text"
            >
              Início
            </NavLink>
            <NavLink
              to="/about"
              className="text-foreground/80 hover:text-foreground transition-colors font-medium"
              activeClassName="text-foreground gradient-text"
            >
              Sobre Mim
            </NavLink>
            <NavLink
              to="/contact"
              className="text-foreground/80 hover:text-foreground transition-colors font-medium"
              activeClassName="text-foreground gradient-text"
            >
              Contato
            </NavLink>
            <NavLink
              to="/shop"
              className="text-foreground/80 hover:text-foreground transition-colors font-medium"
              activeClassName="text-foreground gradient-text"
            >
              Comprar
            </NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
