import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { BadgeCheck, Star, Heart, Shield } from "lucide-react";

const Entrance = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: BadgeCheck,
      text: "Verificadas das principais plataformas",
    },
    {
      icon: Star,
      text: "Serviços exclusivos e personalizados",
    },
    {
      icon: Heart,
      text: "Doce & Ousada",
    },
    {
      icon: Shield,
      text: "Segurança e Privacidade",
    },
  ];

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center px-6 relative"
      style={{
        backgroundImage: `url('/lovable-uploads/entrance-background.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-background/60" />
      
      {/* Hero Section */}
      <div className="text-center mb-20 animate-fade-in relative z-10">
        <h1 className="text-7xl md:text-8xl font-bold mb-6 gradient-text">
          Espaço da Hannah
        </h1>
        <p className="text-2xl md:text-3xl text-foreground/80 mb-12">
          Muito mais que cosplay
        </p>
        <Button
          onClick={() => navigate("/home")}
          size="lg"
          className="bg-gradient-sunset text-foreground font-bold px-12 py-6 text-xl rounded-full hover-glow transition-all duration-300 hover:scale-105"
        >
          Começar
        </Button>
      </div>

      {/* Feature Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl w-full relative z-10">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <div
              key={index}
              className="glass-card p-8 rounded-2xl hover-glow text-center animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <Icon className="w-12 h-12 mx-auto mb-4 text-gradient-orange" />
              <p className="text-foreground/90 font-medium">{feature.text}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Entrance;
