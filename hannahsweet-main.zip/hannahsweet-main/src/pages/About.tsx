const About = () => {
  return (
    <div className="container mx-auto px-4 md:px-6 py-10 md:py-16">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold gradient-text text-center mb-10 md:mb-16">
          Sobre Mim
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 lg:gap-12 items-start">
          {/* Photo Side */}
          <div className="relative lg:col-span-2 mx-auto lg:mx-0 max-w-sm lg:max-w-none w-full">
            <div className="absolute inset-0 bg-gradient-radial blur-3xl -z-10"></div>
            <div className="glass-card rounded-3xl overflow-hidden glow-pink lg:sticky lg:top-8">
              <img 
                alt="Hannah" 
                className="w-full aspect-[3/4] object-cover" 
                src="/lovable-uploads/41672d1b-b6d8-444b-a984-29b34d695c2e.jpg" 
              />
            </div>
          </div>

          {/* Story Side */}
          <div className="space-y-6 lg:col-span-3">
            <div className="glass-card p-5 md:p-8 rounded-2xl">
              <h2 className="text-2xl md:text-3xl font-bold gradient-text mb-4">
                Oii ❤️
              </h2>
              <div className="space-y-3 md:space-y-4 text-foreground/80 text-base md:text-lg leading-relaxed">
                <p>
                  Aqui você vai conhecer um pouquinho do meu mundo, das coisas que eu amo, do meu jeitinho e talvez até descobrir que a gente combina mais do que imagina 👉👈✨️
                </p>
                <p>
                  Tenho 1,60m de altura, 56kg e calço 35/36 ✨️
                </p>
                <p>
                  Quando não estou gravando, você provavelmente vai me ver passeando com meu doguinho, indo à praia ou em casa maratonando meus animes (otaku que fala né? hahaha) ❤️✨️
                </p>
                <p>
                  E claro, fazendo o que mais amo na vida: cosplay. É meu hobby favorito e meu xodó… até hoje não acredito nos cosplays que já fiz e nos que ainda vou fazer. É realmente um sonho pra mim 👉👈🥰
                </p>
                <p>
                  Minhas paixões na cozinha? 😋 Purê de batata com coraçãozinho ao molho de alho, açaí e Trento são meus vícios declarados. Nada deixa meu dia melhor que um açaí bem caprichado 💜
                </p>
                <p>
                  Também sou apaixonada por esportes ✨️ Acompanho vôlei, futebol, NBA, Fórmula 1, Kings League e adoro as Olimpíadas 🥇 E sim… meu time de futebol foi rebaixado 😭 mas em 2026 vamos voltar com tudo pra série A, fé! hahaha
                </p>
                <p>
                  Curiosidade: tenho sotaque sulista, mas se eu fico nervosa ou tímida… do nada sai um carioca hahaha 👉👈
                </p>
                <p>
                  Já perdi as contas de quantos animes assisti, amo treinar, jogar vôlei, academia, e mesmo não gostando tanto de beber água, tento sempre me manter hidratada. Minha alimentação é mais saudável e equilibrada, mas sem neura ✨️✨️
                </p>
                <p>
                  Sou criadora de conteúdo, cosplayer, streamer e enfermeira 🥰❤️ Amo gravar vídeos personalizados do jeitinho que você pedir, te guiando, brincando com meu corpinho, explorando suas fantasias comigo e muito mais do jeitinho que só eu sei fazer ❤️‍🔥
                </p>
                <p>
                  Além do meu conteúdo, também posso ser sua webamiga ou webnamorada ❤️
                </p>
                <p>
                  Tudo com carinho, atenção e exclusividade — do jeitinho único que eu gosto de entregar. Podemos fazer uma chamadinha de vídeo, sexting, avaliação sincera, conversas especiais só nossas ou algo mais específico… é só me chamar e contar o que você deseja ❤️‍🔥 Eu amo inovar, ouvir, satisfazer e te conhecer melhor 😻✨️
                </p>
                <p>
                  Sou intensa, carinhosa, divertida e adoro criar conexões de verdade 👉👈❤️ Se você procura alguém que te trate com atenção, cuidado e aquele toque safadinho na medida… encontrou ❤️‍🔥
                </p>
                <p className="gradient-text font-semibold text-lg md:text-xl">
                  Me chama na DM e vem me descobrir de pertinho. Vou amar te ter comigo. 💕
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 md:gap-4">
              <div className="glass-card p-4 md:p-6 rounded-xl text-center">
                <div className="text-3xl md:text-4xl font-bold gradient-text mb-1 md:mb-2">1000+</div>
                <div className="text-sm md:text-base text-foreground/70">Fotos Exclusivas</div>
              </div>
              <div className="glass-card p-4 md:p-6 rounded-xl text-center">
                <div className="text-3xl md:text-4xl font-bold gradient-text mb-1 md:mb-2">500+</div>
                <div className="text-sm md:text-base text-foreground/70">Vídeos Premium</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;