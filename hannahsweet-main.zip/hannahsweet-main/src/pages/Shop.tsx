import { ExternalLink } from "lucide-react";

const Shop = () => {
  const products = [
    {
      title: "VIP EXCLUSIVO",
      description: "100 mídias com atualização semanal",
      price: "R$ 30,00 mensal",
      image: "/lovable-uploads/vip-exclusivo.jpg",
      link: "https://t.me/HannahSweetbot?start=vibx",
    },
    {
      title: "GRUPO WAIFUZINHAS",
      description: "4 meninas em grupo único",
      price: "R$ 50,00 mensal",
      image: "/lovable-uploads/grupo-waifuzinhas.png",
      link: "https://t.me/Waifuzinhasbot",
    },
  ];

  return (
    <div className="container mx-auto px-6 py-16">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-bold gradient-text text-center mb-4">
          Conteúdos Exclusivos
        </h1>
        <p className="text-xl text-foreground/70 text-center mb-16">
          Premium e personalizado só para você
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {products.map((product, index) => (
            <a
              key={index}
              href={product.link}
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card rounded-2xl overflow-hidden hover-glow transition-all duration-300 hover:scale-105 group"
            >
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2 gradient-text">
                  {product.title}
                </h3>
                <p className="text-foreground/70 mb-4">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-gradient-orange">
                    {product.price}
                  </span>
                  <div className="flex items-center gap-2 text-foreground/60 group-hover:text-foreground/90 transition-colors">
                    <span>Ver mais</span>
                    <ExternalLink className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Shop;
