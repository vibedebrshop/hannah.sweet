import { Lock, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
const Contact = () => {
  const contactMethods = [{
    icon: Lock,
    title: "Privacy",
    value: "@hannahsweet",
    link: "https://privacy.com.br/Checkout/hannahsweet/"
  }, {
    icon: MessageCircle,
    title: "Telegram",
    value: "@CantinhoDaHannah",
    link: "https://t.me/CantinhoDaHannah"
  }];
  return <div className="container mx-auto px-4 md:px-6 py-10 md:py-16">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold gradient-text text-center mb-3 md:mb-4">
          Entre em Contato
        </h1>
        <p className="text-lg md:text-xl text-foreground/70 text-center mb-10 md:mb-16">
          Estou sempre disponível para conversar!
        </p>

        <div className="glass-card p-4 sm:p-6 md:p-12 rounded-2xl md:rounded-3xl mb-8 md:mb-12">
          <div className="space-y-4 md:space-y-8">
            {contactMethods.map((method, index) => {
            const Icon = method.icon;
            return <a key={index} href={method.link} target="_blank" rel="noopener noreferrer" className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 p-4 md:p-6 rounded-2xl hover:bg-card/50 transition-all duration-300 hover-glow group text-center sm:text-left">
                  <div className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-sunset flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                    <Icon className="w-7 h-7 md:w-8 md:h-8 text-background" />
                  </div>
                  <div className="flex-grow">
                    <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">
                      {method.title}
                    </h3>
                    <p className="text-sm md:text-base text-foreground/70">{method.value}</p>
                  </div>
                  <Button variant="outline" className="w-full sm:w-auto border-gradient-orange text-foreground hover:bg-gradient-sunset hover:text-background transition-all">
                    ​Acessar
                  </Button>
                </a>;
          })}
          </div>
        </div>

        <div className="text-center glass-card p-5 md:p-8 rounded-2xl">
          <h3 className="text-xl md:text-2xl font-bold gradient-text mb-3 md:mb-4">
            Precisa de algo personalizado?
          </h3>
          <p className="text-sm md:text-base text-foreground/70 mb-4 md:mb-6">
            Ofereço conteúdo customizado sob encomenda. Entre em contato para discutir suas ideias!
          </p>
          <a href="https://t.me/Hannah_sweet" target="_blank" rel="noopener noreferrer">
            <Button size="lg" className="bg-gradient-sunset text-background font-bold px-6 md:px-8 rounded-full hover-glow text-sm md:text-base">
              ​Atendimento Exclusivo   
            </Button>
          </a>
        </div>
      </div>
    </div>;
};
export default Contact;